# Changes made during port

Note: This template is based on the `eartharxiv_two_column` template. Any changes to that template should be probably updated here too.
In addition the following porting steps were made:

- Removed `two-column` and `switch` options from the `documentclass`
- Removed `two-column` override block, previously responsible for switching off the two column layout for the header section, it's no longer needed
